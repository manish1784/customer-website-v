<template>
  <div class='animate-pulse flex'>
    <div class='h-96 bg-gray-100 rounded-lg w-full'></div>
  </div>
</template>

<script setup>

</script>