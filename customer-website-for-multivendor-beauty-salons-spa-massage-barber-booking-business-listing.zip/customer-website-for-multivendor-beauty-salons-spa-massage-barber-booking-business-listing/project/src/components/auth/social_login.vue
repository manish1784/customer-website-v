<template>
  <div class='mt-6 grid grid-cols-2 gap-3'>
    <div>
      <a
        class='w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'
        href='#'>
        <span class='sr-only'>Sign in with Facebook</span>
        <svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20'>
          <path clip-rule='evenodd'
                d='M20 10c0-5.523-4.477-10-10-10S0 4.477 0 10c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V10h2.54V7.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V10h2.773l-.443 2.89h-2.33v6.988C16.343 19.128 20 14.991 20 10z'
                fill-rule='evenodd' />
        </svg>
      </a>
    </div>

    <div>
      <a
        class='w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'
        href='#'>
        <span class='sr-only'>Sign in with Google</span>
        <svg class='w-5 h-5' fill='currentColor' height='20px' viewBox='0 0 32 32' width='20px'>
          <path
            d='M16.318 13.714v5.484h9.078c-0.37 2.354-2.745 6.901-9.078 6.901-5.458 0-9.917-4.521-9.917-10.099s4.458-10.099 9.917-10.099c3.109 0 5.193 1.318 6.38 2.464l4.339-4.182c-2.786-2.599-6.396-4.182-10.719-4.182-8.844 0-16 7.151-16 16s7.156 16 16 16c9.234 0 15.365-6.49 15.365-15.635 0-1.052-0.115-1.854-0.255-2.651z' />
        </svg>
      </a>
    </div>
  </div>
</template>
