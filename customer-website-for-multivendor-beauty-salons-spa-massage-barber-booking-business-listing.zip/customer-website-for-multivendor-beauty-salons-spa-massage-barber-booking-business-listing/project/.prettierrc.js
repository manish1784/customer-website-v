module.exports = {
    semi: false,
    tabWidth: 2,
    useTabs: true,
    printWidth: 160,
    endOfLine: 'auto',
    singleQuote: true,
    trailingComma: 'es5',
    bracketSpacing: true,
    arrowParens: 'always',
}
